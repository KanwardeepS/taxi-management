--CAB
insert into CAB (DRIVERNAME, STATUS ,LATITUDE, LONGITUDE,ASSIGNEDCITY ) values ('Jason', 'IDLE' , '48.00', '89.00','JAIPUR');
insert into CAB (DRIVERNAME, STATUS ,LATITUDE, LONGITUDE,ASSIGNEDCITY ) values ('Sourabh', 'IDLE' , '69.00' , '88.00','MUMBAI');
insert into CAB (DRIVERNAME, STATUS ,LATITUDE, LONGITUDE,ASSIGNEDCITY ) values ('Peter', 'ON_TRIP' , '45.00' , '40.00','MUMBAI');
insert into CAB (DRIVERNAME, STATUS ,LATITUDE, LONGITUDE,ASSIGNEDCITY ) values ('Pankaj', 'IDLE' , '48.00' , '99.00','MUMBAI');
insert into CAB (DRIVERNAME, STATUS ,LATITUDE, LONGITUDE,ASSIGNEDCITY ) values ('Ravinder', 'IDLE' , '69.00' , '88.00','MUMBAI');
insert into CAB (DRIVERNAME, STATUS ,LATITUDE, LONGITUDE,ASSIGNEDCITY ) values ('Beny', 'ON_TRIP' , '48.00' , '49.00','JAIPUR');
						
--CUSTOMER						
insert into CUSTOMER (CUSTOMERID,CUSTOMERNAME, EMAIL ,MOBILE ) values ('1','Rohan', 'Email1@test' , '5858585885');
insert into CUSTOMER (CUSTOMERID,CUSTOMERNAME, EMAIL ,MOBILE ) values ('2','Vaibhav', 'Email2@test' , '9128585885');



--BOOKING							
insert into BOOKING (BOOKINGID,CUSTOMERID, CABID ,DISTANCE,CHARGINGAMOUNT ) values ('1','1', '1' , '11.00','340.00');						
insert into BOOKING (BOOKINGID,CUSTOMERID, CABID ,DISTANCE,CHARGINGAMOUNT ) values ('2','1', '2' , '15.00','440.00');		
insert into BOOKING (BOOKINGID,CUSTOMERID, CABID ,DISTANCE,CHARGINGAMOUNT ) values ('3','2', '1' , '7.00','240.00');	


--CITY							
insert into CITY (CITYID, CITYNAME ,STATENAME,PINCODE, COUNTRY) values ('1', 'Pune' , 'Maharashtra','411016', 'India');						
insert into CITY (CITYID, CITYNAME ,STATENAME,PINCODE, COUNTRY ) values ('2', 'Delhi' , 'Delhi','110001', 'India');		
insert into CITY (CITYID, CITYNAME ,STATENAME,PINCODE, COUNTRY ) values ('3', 'Mumbai' , 'Maharashtra','400001', 'India');		
insert into CITY (CITYID, CITYNAME ,STATENAME,PINCODE, COUNTRY ) values ('4', 'Jammu' , 'J&K','180001', 'India');	