drop table CAB if exists;
create table CAB (CABID bigint identity primary key, 
						DRIVERNAME varchar(100) not null,
						STATUS varchar(20) not null,
						LATITUDE float,
						LONGITUDE float,
						ASSIGNEDCITY varchar(10) not null);		
						
drop table CUSTOMER if exists;
create table CUSTOMER (CUSTOMERID bigint identity primary key, 
						CUSTOMERNAME varchar(100) not null,
						EMAIL varchar(100) not null,
						MOBILE varchar(10) not null);	
						
drop table BOOKING if exists;
create table BOOKING (BOOKINGID bigint identity primary key, 
						CUSTOMERID bigint not null,
						CABID bigint not null,
						DISTANCE decimal(4,2),
						CHARGINGAMOUNT decimal(5,2));	

drop table CITY if exists;
create table CITY (CITYID bigint identity primary key, 
						CITYNAME varchar(100) not null,
						STATENAME varchar(100) not null,
						PINCODE varchar(255) not null,
						COUNTRY varchar(255) not null);							