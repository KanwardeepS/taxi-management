package com.test.microservices.cmp.booking;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.microservices.cmp.cab.Cab;
import com.test.microservices.cmp.cab.CabRepository;
import com.test.microservices.cmp.city.CityRepository;
import com.test.microservices.cmp.customer.Customer;
import com.test.microservices.cmp.customer.CustomerRepository;

@RestController
public class BookingService {
	protected Logger logger = Logger.getLogger( BookingController.class.getName() );
	protected BookingRepository bookingRepository;
	protected CabRepository cabRepository;
	protected CustomerRepository customerRepository;
	protected CityRepository cityRepository;
	
	
	@Autowired
	public BookingService( BookingRepository BookingRepository ,CabRepository cabRepository ,CustomerRepository customerRepository,CityRepository cityRepository ) {
		this.bookingRepository = BookingRepository;
		logger.info( "BookingRepository says system has " + bookingRepository.count() + " Bookings" );
		this.cabRepository = cabRepository;
		logger.info( "cabRepository says system has " + cabRepository.count() + " cabs" );
		this.customerRepository = customerRepository;
		logger.info( "customerRepository says system has " + customerRepository.count() + " customers" );
		this.cityRepository = cityRepository;
		logger.info( "cityRepository says system has " + cityRepository.count() + " cities" );
	}
	
	
	@RequestMapping( value = "/book/ride", method = RequestMethod.POST )
	public Cab bookride( @RequestBody Customer customer ) {
		List<Cab> availableCabs = new ArrayList<Cab>();
		availableCabs = cabRepository.findByStatus("IDLE");
		Random rand = new Random();
		logger.info( "available cabs from bookride() invoked: " + availableCabs.size() );
		Cab cab = availableCabs.get(rand.nextInt(availableCabs.size()));
		//TODO:
		//1. Logic to find the nearest cab which has been idle for longest time
		//2. logic if there are multiple cabs available, choose random among them.
		//find the distance based on the destination of customer and source of customer
		//properties to be included
		//source longitude,latitude to be added in Customer as current location.
		//Destination longitude,latitude to be added in Customer as current location.
		Booking bookingMade = new Booking(customer.getCustomerid(),cab.getCabid(),new BigDecimal(15),new BigDecimal(350));
		bookingRepository.save(bookingMade);
		cab.setStatus(Cab.CabState.ON_TRIP.getState());
		cabRepository.save(cab);
		return cab;
	}
}
