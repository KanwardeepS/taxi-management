package com.test.microservices.cmp.booking;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BOOKING")
public class Booking implements Serializable {
		private static final long serialVersionUID = 3L;
		public static Long nextId = 0L;
		
		public Booking() {
			super();
		}

		public Booking(  Long customerid, Long cabid, BigDecimal distance, BigDecimal chargingAmount ) {
			super();
			this.bookingid = getNextId();
			this.customerid = customerid;
			this.cabid = cabid;
			this.distance = distance;
			this.chargingamount = chargingAmount;
		}

		@Id
		@Column(name = "bookingid")
		protected Long bookingid;
		
		@Column(name = "customerid")
		private Long customerid;
		
		@Column(name = "cabid")
		private Long cabid;
		
		@Column(name = "distance")
		private BigDecimal distance; 
		
		@Column(name = "chargingamount")
		private BigDecimal chargingamount; 
		
		protected static Long getNextId() {
			synchronized (nextId) {
				return nextId++;
			}
		}

		public Long getBookingid() {
			return bookingid;
		}

		public void setBookingid(Long bookingid) {
			this.bookingid = bookingid;
		}

		public Long getCustomerid() {
			return customerid;
		}

		public void setCustomerid(Long customerid) {
			this.customerid = customerid;
		}

		public Long getCabid() {
			return cabid;
		}

		public void setCabid(Long cabid) {
			this.cabid = cabid;
		}

		public BigDecimal getDistance() {
			return distance;
		}

		public void setDistance(BigDecimal distance) {
			this.distance = distance;
		}

		public BigDecimal getChargingamount() {
			return chargingamount;
		}

		public void setChargingamount(BigDecimal chargingamount) {
			this.chargingamount = chargingamount;
		}

		@Override
		public String toString() {
			return "Booking [bookingid=" + bookingid + ", customerid=" + customerid + ", cabid=" + cabid + ", distance="
					+ distance + ", chargingamount=" + chargingamount + "]";
		}
}
