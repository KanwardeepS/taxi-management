package com.test.microservices.cmp.booking;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.microservices.cmp.exceptions.RecordNotFoundException;
@RestController
public class BookingController {
	
	protected Logger logger = Logger.getLogger( BookingController.class.getName() );
	protected BookingRepository bookingRepository;
	
	@Autowired
	public BookingController( BookingRepository BookingRepository ) {
		this.bookingRepository = BookingRepository;
		logger.info( "BookingRepository says system has " + BookingRepository.count() + " Bookings" );
	}

	@RequestMapping( value = "/booking/create", method = RequestMethod.POST )
	public List<Booking> createbooking( @RequestBody Booking booking ) {
		logger.info( "booking-service createBooking() invoked: " + booking );
		bookingRepository.save( new Booking(booking.getCustomerid(),booking.getCabid(),booking.getDistance(),booking.getChargingamount()));
		return bookingRepository.findAll();

	}

	@RequestMapping( value = "/booking/delete/{bookingid}", method = RequestMethod.GET )
	public List<Booking> deletebooking( @PathVariable( "bookingid" ) Long bookingId ) {
		logger.info( "booking-service deleteBooking() invoked: " + bookingId );
		bookingRepository.delete( bookingId );
		return bookingRepository.findAll();
	}
	
	@RequestMapping("/booking/bookingid/{bookingid}")
	public List<Booking> findBybookingId(@PathVariable("bookingid") Long bookingId) {
		logger.info("booking-service findBybookingId() invoked: " + bookingId);
		List<Booking> bookingList = bookingRepository.findByBookingid(bookingId);
		logger.info("Booking-service findBybookingId() found: " + bookingList);
		if (bookingList == null)
			throw new RecordNotFoundException("bookingId: "+bookingId);
		else {
			return bookingList;
		}
	}
	
	@RequestMapping("/booking/cabid/{cabid}")
	public List<Booking> findByCabId(@PathVariable("cabid") Long cabid) {
		logger.info("booking-service findByCabId() invoked: " + cabid);
		List<Booking> bookingList = bookingRepository.findByCabid(cabid);
		logger.info("Booking-service findByCabId() found: " + bookingList);
		if (bookingList == null)
			throw new RecordNotFoundException("cabid: "+cabid);
		else {
			return bookingList;
		}
	}
	
	@RequestMapping("/booking/customerid/{customerid}")
	public List<Booking> findByCustomerId(@PathVariable("customerid") Long customerId) {
		logger.info("booking-service findByCustomerId() invoked: " + customerId);
		List<Booking> bookingList = bookingRepository.findByCustomerid(customerId);
		logger.info("Booking-service findByCustomerId() found: " + customerId);
		if (bookingList == null)
			throw new RecordNotFoundException("customerId: "+customerId);
		else {
			return bookingList;
		}
	}
	
}
