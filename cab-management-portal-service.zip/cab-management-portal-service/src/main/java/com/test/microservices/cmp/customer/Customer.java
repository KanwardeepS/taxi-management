package com.test.microservices.cmp.customer;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CUSTOMER")
public class Customer implements Serializable {
	private static final long serialVersionUID = 2L;
	public static Long nextId = 0L;
	
	public Customer() {
		super();
	}

	public Customer( String p_customerName, String emailID,String mobileNo  ) {
		super();
		customerid = getNextId();
		customerName = p_customerName;
		email = emailID;
		mobile = mobileNo;
	}
	
	

	@Id
	@Column(name = "customerid")
	protected Long customerid;
	
	@Column(name = "customername")
	protected String customerName;
	
	@Column(name = "email")
	protected String email;
	
	@Column(name = "mobile")
	protected String mobile;
	
	protected static Long getNextId() {
		synchronized (nextId) {
			return nextId++;
		}
	}

	public Long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Long customerid) {
		this.customerid = customerid;
	}
	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerid + ", customerName=" + customerName + ", email=" + email
				+ ", mobile=" + mobile + "]";
	}

}

