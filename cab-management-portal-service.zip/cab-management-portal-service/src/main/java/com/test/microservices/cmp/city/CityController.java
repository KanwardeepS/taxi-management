package com.test.microservices.cmp.city;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.microservices.cmp.exceptions.RecordNotFoundException;
@RestController
public class CityController {
	
	protected Logger logger = Logger.getLogger( CityController.class.getName() );
	protected CityRepository cityRepository;
	
	@Autowired
	public CityController( CityRepository CityRepository ) {
		this.cityRepository = CityRepository;
		logger.info( "CityRepository says system has " + CityRepository.count() + " Citys" );
	}

	@RequestMapping( value = "/city/create", method = RequestMethod.POST )
	public List<City> createCity( @RequestBody City City ) {
		logger.info( "City-service createCity() invoked: " + City );
		cityRepository.save( new City(City.getCityname(),City.getState(),City.getPincode(),City.getCountry()));
		return cityRepository.findAll();

	}

	@RequestMapping( value = "/city/delete/{CityId}", method = RequestMethod.GET )
	public List<City> deleteCity( @PathVariable( "CityId" ) Long CityId ) {
		logger.info( "City-service deleteCity() invoked: " + CityId );
		cityRepository.delete( CityId );
		return cityRepository.findAll();
	}
	
	
	@RequestMapping("/city/cityid/{cityid}")
	public List<City> findByCityId(@PathVariable("cityid") Long cityId) {
		logger.info("City-service findByCityId() invoked: " + cityId);
		List<City> CityList = cityRepository.findByCityid(cityId);
		logger.info("City-service findByCityId() found: " + CityList);
		if (CityList == null)
			throw new RecordNotFoundException("cityid: "+cityId);
		else {
			return CityList;
		}
	}
	
	@RequestMapping("/city/cityname/{cityname}")
	public List<City> findByCityName(@PathVariable("cityname") String cityname) {
		logger.info("City-service findByCityName() invoked: " + cityname);
		List<City> CityList = cityRepository.findByCityname(cityname);
		logger.info("City-service findByCityName() found: " + cityname);
		if (CityList == null)
			throw new RecordNotFoundException("cityname: "+cityname);
		else {
			return CityList;
		}
	}
	
	
}
