package com.test.microservices.cmp.customer;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.microservices.cmp.exceptions.RecordNotFoundException;
@RestController
public class CustomerController {
	
	protected Logger logger = Logger.getLogger( CustomerController.class.getName() );
	protected CustomerRepository customerRepository;
	
	@Autowired
	public CustomerController( CustomerRepository cabRepository ) {
		this.customerRepository = cabRepository;
		logger.info( "CabRepository says system has " + cabRepository.count() + " cabs" );
	}

	@RequestMapping( value = "/customer/create", method = RequestMethod.POST )
	public List<Customer> createCustomer( @RequestBody Customer customer ) {
		logger.info( "Customer-service createCab() invoked: " + customer );
		customerRepository.save( new Customer(customer.getCustomerName(),customer.getEmail(),customer.getMobile()));
		return customerRepository.findAll();

	}

	@RequestMapping( value = "/customer/delete/{customerId}", method = RequestMethod.GET )
	public List<Customer> deleteCustomer( @PathVariable( "customerId" ) Long cabId ) {
		logger.info( "Customer-service deleteCab() invoked: " + cabId );
		customerRepository.delete( cabId );
		return customerRepository.findAll();
	}
	
	@RequestMapping("/customer/customerid/{customerid}")
	public List<Customer> findByCustomerId(@PathVariable("customerid") Long customerId) {
		logger.info("Customer-service findByCustomerId() invoked: " + customerId);
		List<Customer> customerList = customerRepository.findByCustomerid(customerId);
		logger.info("cab-service findByCustomerId() found: " + customerList);
		if (customerList == null)
			throw new RecordNotFoundException("customerId: "+customerId);
		else {
			return customerList;
		}
	}
	
	@RequestMapping("/customer/email/{emailId}")
	public List<Customer> findByEmailId(@PathVariable("emailId") String emailId) {
		logger.info("Customer-service findByEmailId() invoked: " + emailId);
		List<Customer> cabList = customerRepository.findByEmail(emailId);
		logger.info("cab-service findByEmailId() found: " + cabList);
		if (cabList == null)
			throw new RecordNotFoundException(emailId);
		else {
			return cabList;
		}
	}
}
