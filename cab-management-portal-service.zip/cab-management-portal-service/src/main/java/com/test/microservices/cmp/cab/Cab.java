package com.test.microservices.cmp.cab;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CAB")
public class Cab implements Serializable {
	private static final long serialVersionUID = 1L;
	public static Long nextId = 0L;
	
	public Cab() {
		super();
	}

	public Cab( String p_customerName, String cab_status, double curlatitude, double curlongitude, String assignedCity ) {
		super();
		cabid = getNextId();
		driverName = p_customerName;
	
		latitude = curlatitude ;
		longitude= curlongitude ;
		assignedcity=assignedCity;
		status = cab_status;
		//In case the Cab_State is ON_TRIP, the City_Id will be indeterminate
		if(null!=status && CabState.ON_TRIP.equals(cab_status)){
			assignedcity=null;
		}
	}

	

	@Id
	@Column(name = "cabid")
	protected Long cabid;
	
	@Column(name = "drivername")
	protected String driverName;
	
	@Column(name = "status")
	protected String status;

	@Column(name = "latitude")
	private double latitude;
	
	@Column(name = "longitude")
	private double longitude;
	
	@Column(name = "assignedcity")
	private String assignedcity;
	
	
	public Long getCabid() {
		return cabid;
	}

	public void setCabid(Long cabid) {
		this.cabid = cabid;
	}
	
	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String name) {
		this.driverName = name;
	}
	
	protected static Long getNextId() {
		synchronized (nextId) {
			return nextId++;
		}
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getAssignedcity() {
		return assignedcity;
	}

	public void setAssignedcity(String assignedcity) {
		this.assignedcity = assignedcity;
	}

	@Override
	public String toString() {
		return "Cab [cabid=" + cabid + ", driverName=" + driverName + ", status=" + status + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", assignedcity=" + assignedcity + "]";
	}
	
	/**
	 * Enum to manage the state of the cab
	 *
	 */
	public enum CabState {
		ON_TRIP("ON_TRIP"), IDLE("IDLE"), BROKEN("BROKEN");
		private  String cabState;
		private CabState(String cabState) {
			this.cabState = cabState;
		}
		
		public String getState() {
			return cabState;
		}
		
		public static CabState getCabState(String cabstate) {
			for(CabState cabState : CabState.values()) {
				if(null!=cabstate && cabState.getState().equals(cabstate)) {
					return cabState;
				}
			}
			return null;
		}
	}
}
