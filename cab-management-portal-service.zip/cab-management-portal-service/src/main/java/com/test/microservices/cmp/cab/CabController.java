package com.test.microservices.cmp.cab;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.microservices.cmp.exceptions.RecordNotFoundException;
import com.test.microservices.cmp.validators.ValidationUtil;
@RestController
public class CabController {
	
	protected Logger logger = Logger.getLogger( CabController.class.getName() );
	protected CabRepository cabRepository;
	
	@Autowired
	public CabController( CabRepository cabRepository ) {
		this.cabRepository = cabRepository;
		logger.info( "CabRepository says system has " + cabRepository.count() + " cabs" );
	}

	
	/**
	 * Method to load data for all Cabs in one go
	 */
	@RequestMapping( value = "/cab/createAll", method = RequestMethod.POST )
	public List<Cab> createAll( @RequestBody List<Cab> cabList ) {
		logger.info( "cab-service createAll() invoked: " + cabList.size() );
		final List<Cab> cabsRegList = new ArrayList<Cab>();
		cabList.forEach(cab->{
			Cab cabToBeRegistered = new Cab(cab.getDriverName(),cab.getStatus(),cab.getLatitude() ,cab.getLongitude(),cab.getAssignedcity());
			cabsRegList.add(cabToBeRegistered);
		});
		cabRepository.save(cabsRegList);
		return cabRepository.findAll();
	}
	
	
	@RequestMapping( value = "/cab/create", method = RequestMethod.POST )
	public List<Cab> createCab( @RequestBody Cab cab ) {
		logger.info( "cab-service createCab() invoked: " + cab );
		cabRepository.save( new Cab(cab.getDriverName(),cab.getStatus(),cab.getLatitude() ,cab.getLongitude(),cab.getAssignedcity()));
		return cabRepository.findAll();

	}
	
	/**
	 * A general update method can be also used to :
	 * Change CITY  for a cab
	 * Change STATE  for a cab
	 */
	@RequestMapping( value = "/cab", method = RequestMethod.PUT )
	public Cab update( @RequestBody Cab cab ) {
		logger.info( "cab-service createCab() invoked: " + cab );
		if(ValidationUtil.isValidCabState(cab) ){
			cabRepository.save(cab);
			return  cabRepository.findOne(cab.getCabid());
		}else{
			//TODO: Create new Exception
			throw new RecordNotFoundException("Cab status not valid " , cab.getStatus() );
		}
	}

	@RequestMapping( value = "/cab/delete/{cabId}", method = RequestMethod.GET )
	public List<Cab> deleteCab( @PathVariable( "cabId" ) Long cabId ) {
		logger.info( "cab-service deleteCab() invoked: " + cabId );
		cabRepository.delete( cabId );
		return cabRepository.findAll();
	}
	
	@RequestMapping("/cab/status/{status}")
	public List<Cab> findByStatus(@PathVariable("status") String status) {
		logger.info("cab-service findByStatus() invoked: " + status);
		List<Cab> cabList = cabRepository.findByStatus(status);
		logger.info("cab-service findByStatus() found: " + cabList);
		if (cabList == null)
			throw new RecordNotFoundException(status);
		else {
			return cabList;
		}
	}
	
	@RequestMapping("/cab/name/{driverName}")
	public List<Cab> findByDriverName(@PathVariable("driverName") String driverName) {
		logger.info("cab-service findByDriverName() invoked: " + driverName);
		List<Cab> cabList = cabRepository.findByDriverName(driverName);
		logger.info("cab-service findByDriverName() found: " + cabList);
		if (cabList == null)
			throw new RecordNotFoundException(driverName);
		else {
			return cabList;
		}
	}
	
	
	

}
