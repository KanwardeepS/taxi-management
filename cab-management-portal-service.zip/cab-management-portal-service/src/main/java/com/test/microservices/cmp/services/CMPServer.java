package com.test.microservices.cmp.services;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Import;

import com.test.microservices.cmp.CMPConfiguration;
import com.test.microservices.cmp.cab.CabRepository;

@EnableAutoConfiguration
@Import(CMPConfiguration.class)
public class CMPServer {

	@Autowired
	protected CabRepository cabRepository;

	protected Logger logger = Logger.getLogger(CMPServer.class.getName());

	
	public static void main(String[] args) {
		System.setProperty("spring.config.name", "cmp-server");
		SpringApplication.run(CMPServer.class, args);
	}

}
