package com.test.microservices.cmp.booking;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface BookingRepository  extends JpaRepository<Booking, Long> {
	
	@Query("SELECT count(*) from Booking")
	public int countBookings();
	public List<Booking> findByBookingid(Long bookingId);
	public List<Booking> findByCustomerid(Long customerId);
	public List<Booking> findByCabid(Long cabId);
}
