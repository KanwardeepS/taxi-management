package com.test.microservices.cmp.validators;

import com.test.microservices.cmp.cab.Cab;

public class ValidationUtil {
	
	
	public static boolean isValidCabState(Cab cab){
		boolean isValid = false;
		if (null!=Cab.CabState.getCabState(cab.getStatus())){
			isValid = true;
		}
		return isValid;
	}
	
	
	public static boolean isValidCity(Cab cab){
		boolean isValid = false;
		//Logic to check if the city is registered city for operations.
		return isValid;
	}
	
}
