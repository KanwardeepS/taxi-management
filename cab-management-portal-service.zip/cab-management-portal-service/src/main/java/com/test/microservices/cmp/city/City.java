package com.test.microservices.cmp.city;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CITY")
public class City implements Serializable {
	private static final long serialVersionUID = 2L;
	public static Long nextId = 0L;
	
	public City() {
		super();
	}

	public City( String citiName, String stateName,String pin,String countryName  ) {
		super();
		this.cityid = getNextId();
		this.cityname = citiName;
		this.statename = stateName;
		this.pincode = pin;
		this.country = countryName;
	}
	
	protected static Long getNextId() {
		synchronized (nextId) {
			return nextId++;
		}
	}
	
	@Id
	@Column(name = "cityid")
	protected Long cityid;
	
	@Column(name = "cityname")
	protected String cityname;
	
	@Column(name = "STATENAME")
	protected String statename;
	
	
	@Column(name = "pincode")
	protected String pincode;
	
	@Column(name = "country")
	protected String country;

	public Long getCityid() {
		return cityid;
	}

	public void setCityid(Long cityid) {
		this.cityid = cityid;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getState() {
		return statename;
	}

	public void setState(String state) {
		this.statename = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "City [cityid=" + cityid + ", cityname=" + cityname + ", state=" + statename + ", pincode=" + pincode
				+ ", country=" + country + "]";
	}

}
