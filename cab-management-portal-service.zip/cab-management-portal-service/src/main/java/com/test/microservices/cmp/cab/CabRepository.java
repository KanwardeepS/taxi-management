package com.test.microservices.cmp.cab;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface CabRepository  extends JpaRepository<Cab, Long> {
	
	@Query("SELECT count(*) from Cab")
	public int countCabs();
	public List<Cab> findByStatus(String status);
	public List<Cab> findByDriverName(String driverName);
	//public List<Cab> updateCab(Cab cab);
}
