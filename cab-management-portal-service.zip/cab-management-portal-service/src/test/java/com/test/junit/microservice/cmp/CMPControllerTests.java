package com.test.junit.microservice.cmp;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.test.microservices.cmp.cab.Cab;
import com.test.microservices.cmp.cab.CabController;
import com.test.microservices.cmp.cab.CabRepository;


public class CMPControllerTests {

	

	@Autowired
	CabController cabController;

	protected TestCabRepository testRepo = new TestCabRepository();

	@Test
	public void validDriverName() {
	
	}
	
	
	@Test
	public void validCabState() {
		
	}
	


	@Before
	public void setup() {
		cabController = new CabController( testRepo );
	}

	protected static class TestCabRepository implements CabRepository {

		@Override
		public void deleteAllInBatch() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void deleteInBatch(Iterable<Cab> arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public List<Cab> findAll() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public List<Cab> findAll(Sort arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public List<Cab> findAll(Iterable<Long> arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void flush() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Cab getOne(Long arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public <S extends Cab> List<S> save(Iterable<S> arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public <S extends Cab> S saveAndFlush(S arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Page<Cab> findAll(Pageable arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long count() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public void delete(Long arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void delete(Cab arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void delete(Iterable<? extends Cab> arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void deleteAll() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public boolean exists(Long arg0) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public Cab findOne(Long arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public <S extends Cab> S save(S arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public int countCabs() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public List<Cab> findByStatus(String status) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public List<Cab> findByDriverName(String driverName) {
			// TODO Auto-generated method stub
			return null;
		}

		/*@Override
		public List<Cab> updateCab(Cab cab) {
			// TODO Auto-generated method stub
			return null;
		}
*/
		
 
 

		

	}

}
